//
//  MenuTableViewController.h
//  SnipNews
//
//  Created by NETBIZ on 23/01/17.
//  Copyright © 2017 NetBiz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuTableViewController : UITableViewController
{
    NSArray * newsCategories;
}
@end
